module.exports.renderSketch = function (filename, extras, html) {
  extras = extras || [];
  html = html || 'sketch';
  return function(req, res){
    res.render(html, {
      sketch: './src/'+filename+'.js',
      extras: extras.map((el) => './src/objects/'+el+'.js')
    });
  }
};

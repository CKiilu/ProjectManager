const express = require('express');
const renderSketch = require('./middleware').renderSketch;
const route = express.Router();



module.exports = route;

const express = require('express');
const app = express();
const routeConfig = require('./routes/routes');

app.use(express.static("./static"));
app.set("view engine", "pug");

app.get("/", function(req, res){
	res.render("index");
});

app.use('/', routeConfig);

const server = app.listen(process.env.PORT || 8000, function(){
	const address = server.address();
	console.log("Server is is running on port "+address.port);
});
